import './App.css';
import Button2 from './Button2';
import 'bootstrap/dist/css/bootstrap.min.css';

function App() {
  return (
    <Button2/>

  );
}

export default App;
